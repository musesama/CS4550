README.md for HW02

HW02 Subdomain URL: http://hw02.viceroix.com
Git repo: https://github.com/musesama/WebDev/tree/master/cs4550%20WebDev
